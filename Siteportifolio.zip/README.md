# BRV Digital - Portfólio de Alta Conversão

Portfólio profissional para **BRV Digital / Bruno Ribeiro** focado em captação de clientes e conversão via WhatsApp.

## 🚀 Tecnologias Utilizadas
- **React 19**
- **Vite**
- **TypeScript**
- **Tailwind CSS v4**
- **Lucide React** (Ícones)
- **Motion**

## 💻 Como Rodar Localmente

1. Extraia os arquivos do projeto.
2. No terminal, instale as dependências:
```bash
npm install
```
3. Inicie o servidor de desenvolvimento:
```bash
npm run dev
```
4. Acesse no navegador: `http://localhost:3000` (ou a porta indicada no terminal).

## 🌐 Como Hospedar na Netlify (Grátis em 1 minuto)

### Opção 1: Arrastar e Soltar (Drag & Drop)
1. Rode no seu terminal:
```bash
npm run build
```
2. Acesse [app.netlify.com](https://app.netlify.com).
3. Vá em **Sites** > arraste e solte a pasta **`dist`** diretamente na área indicada.
4. Seu site estará online com HTTPS gratuito imediatamente!

### Opção 2: Conectar com GitHub
- **Build command:** `npm run build`
- **Publish directory:** `dist`

## 💜 Como usar no Lovable
1. No Lovable, crie um novo projeto ou importe este repositório/pasta.
2. Os componentes estão estruturados de forma modular em `src/components/`, `src/data/`, e `src/types/`.
3. Todos os arquivos e imagens estão organizados em `public/assets/`.
