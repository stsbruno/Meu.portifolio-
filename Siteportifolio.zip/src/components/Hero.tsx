import React from 'react';
import { BRAND, IMAGES } from '../data/content';
import { MessageCircle, ArrowRight, ShieldCheck, Zap, Clock, Sparkles } from 'lucide-react';

export const Hero: React.FC = () => {
  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-28 bg-[#05070E] text-white overflow-hidden">
      {/* Sleek circular neon blue ambient backdrop matching the logo */}
      <div
        className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[650px] rounded-full pointer-events-none opacity-25 blur-[120px]"
        style={{
          background: 'radial-gradient(circle, #00A3FF 0%, #0055FF 50%, transparent 75%)',
        }}
      />
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.04]"
        style={{
          backgroundImage: `linear-gradient(to right, #00A3FF 1px, transparent 1px), linear-gradient(to bottom, #00A3FF 1px, transparent 1px)`,
          backgroundSize: '40px 40px',
        }}
      />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Value Proposition & CTAs (7 cols) */}
          <div className="lg:col-span-7 space-y-8 text-left">
            {/* Tagline / Subtitle as clean unboxed text with neon touch */}
            <div className="inline-flex items-center gap-2.5 px-3 py-1.5 rounded-full bg-blue-950/60 border border-blue-500/30 text-xs font-semibold tracking-wider text-blue-300 shadow-[0_0_15px_rgba(0,163,255,0.15)]">
              <span className="w-2 h-2 rounded-full bg-[#00A3FF] shadow-[0_0_8px_#00A3FF]" />
              <span className="tracking-widest uppercase">BRV DIGITAL</span>
              <span aria-hidden="true" className="text-blue-500">·</span>
              <span className="text-white">SITES QUE GERAM RESULTADOS</span>
            </div>

            {/* Impactful headline with balanced text */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-[3.25rem] font-black tracking-tight text-white leading-[1.15] text-balance">
              Transformamos a sua presença digital em <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00C2FF] via-[#0084FF] to-white underline decoration-[#00A3FF]/50 underline-offset-8">oportunidades</span> reais de negócio.
            </h1>

            {/* Sub-headline addressing the target audience */}
            <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
              Criação de sites e landing pages de alto padrão para pequenas empresas e profissionais liberais que desejam transmitir autoridade inquestionável e atrair clientes qualificados pela internet.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              <a
                href={BRAND.getWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-3 bg-gradient-to-r from-[#0066FF] to-[#00A3FF] hover:from-[#0055DD] hover:to-[#0090EE] text-white font-bold text-base px-7 py-4 rounded-xl shadow-[0_0_25px_rgba(0,163,255,0.45)] hover:shadow-[0_0_35px_rgba(0,163,255,0.6)] transition-all duration-200 transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
              >
                <MessageCircle className="w-5 h-5 text-white" />
                <span className="whitespace-nowrap">Solicitar Orçamento no WhatsApp</span>
              </a>

              <a
                href="#portfolio"
                className="inline-flex items-center justify-center gap-2 border border-slate-700/80 hover:border-blue-500/60 bg-[#0C111E]/80 hover:bg-[#10182A] text-slate-200 hover:text-white font-medium text-base px-6 py-4 rounded-xl transition-all whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
              >
                <span>Ver Projetos Entregues</span>
                <ArrowRight className="w-4 h-4 text-[#00A3FF]" />
              </a>
            </div>

            {/* Proof & Trust Markers (clean unboxed text with bullets) */}
            <div className="pt-4 border-t border-white/10 flex flex-wrap items-center gap-y-2 gap-x-4 text-xs sm:text-sm text-slate-300">
              <div className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Entrega ágil e sem burocracia</span>
              </div>
              <span className="text-slate-600 hidden sm:inline" aria-hidden="true">·</span>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Atendimento direto com Bruno</span>
              </div>
              <span className="text-slate-600 hidden sm:inline" aria-hidden="true">·</span>
              <div className="flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Foco em Alta Conversão</span>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Showcase (5 cols) */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-lg lg:max-w-none">
              {/* Decorative subtle backdrop halo */}
              <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl blur-xl opacity-20 -z-10" />

              {/* Main mockup card frame */}
              <div className="relative rounded-2xl overflow-hidden border border-blue-500/30 bg-[#0C111E] shadow-[0_0_35px_rgba(0,163,255,0.2)] transition-transform duration-300 hover:scale-[1.01]">
                {/* Browser top chrome */}
                <div className="flex items-center justify-between px-4 py-3 bg-[#080D18] border-b border-white/10">
                  <div className="flex items-center gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-500/80" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                    <div className="w-3 h-3 rounded-full bg-green-500/80" />
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1 bg-black/60 rounded-md border border-white/10 text-[11px] text-slate-400 font-mono">
                    <span className="text-[#00C2FF]">https://</span>
                    <span>seunegocio.com.br</span>
                  </div>
                  <div className="w-6" />
                </div>

                {/* Hero Showcase Image */}
                <div className="relative aspect-[16/10] bg-black overflow-hidden">
                  <img
                    src={IMAGES.hero}
                    alt="Demonstração de sites responsivos e landing pages desenvolvidas pela BRV Digital"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center"
                    loading="eager"
                  />
                  {/* Subtle contrast scrim */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0C111E]/80 via-transparent to-transparent pointer-events-none" />
                </div>

                {/* Bottom Card Summary Bar */}
                <div className="p-4 sm:p-5 bg-[#0C111E] border-t border-white/10 flex items-center justify-between gap-4">
                  <div>
                    <div className="text-xs text-slate-400 font-medium">Design sob medida</div>
                    <div className="text-sm font-semibold text-white">Carregamento instantâneo & Mobile First</div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-xs font-mono text-[#00C2FF] font-semibold tabular-nums">98/100</div>
                    <div className="text-[11px] text-slate-400">Google PageSpeed</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
