import React, { useState } from 'react';
import { BRAND } from '../data/content';
import { MessageCircle, X } from 'lucide-react';

export const FloatingWhatsApp: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(true);

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end pointer-events-auto">
      {/* Friendly Tooltip / Chat bubble */}
      {showTooltip && (
        <div className="relative mb-3 bg-[#0C111E]/95 backdrop-blur-md p-3.5 rounded-2xl shadow-[0_0_25px_rgba(0,163,255,0.25)] border border-blue-500/40 text-xs text-slate-200 max-w-[240px] animate-fade-in group">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowTooltip(false);
            }}
            type="button"
            className="absolute top-1.5 right-1.5 text-slate-400 hover:text-white p-0.5 rounded-full"
            aria-label="Fechar aviso do WhatsApp"
          >
            <X className="w-3.5 h-3.5" />
          </button>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-2 h-2 rounded-full bg-[#00C2FF] shadow-[0_0_8px_#00C2FF]" />
            <span className="font-bold text-white">Bruno Ribeiro</span>
          </div>
          <p className="text-[12px] text-slate-300 leading-snug">
            Olá! Precisa de um site ou landing page? Fale comigo agora no WhatsApp.
          </p>
        </div>
      )}

      {/* Main Floating Button */}
      <a
        href={BRAND.getWhatsAppUrl()}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Abrir conversa no WhatsApp com Bruno Ribeiro"
        className="w-14 h-14 rounded-full bg-[#25D366] hover:bg-[#1EBE5D] text-white flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-emerald-400/50"
      >
        <MessageCircle className="w-7 h-7 fill-white text-white" />
      </a>
    </div>
  );
};
