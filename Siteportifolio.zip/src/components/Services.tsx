import React from 'react';
import { SERVICES, BRAND } from '../data/content';
import { MessageCircle, Check, ArrowRight, Globe, Layers, Search, ShoppingBag } from 'lucide-react';

export const Services: React.FC = () => {
  const getServiceIcon = (id: string) => {
    switch (id) {
      case 'criacao-sites':
        return <Globe className="w-6 h-6 text-[#00C2FF]" />;
      case 'landing-pages':
        return <Layers className="w-6 h-6 text-[#00C2FF]" />;
      case 'otimizacao-google':
        return <Search className="w-6 h-6 text-[#00C2FF]" />;
      case 'paginas-venda':
        return <ShoppingBag className="w-6 h-6 text-[#00C2FF]" />;
      default:
        return <Globe className="w-6 h-6 text-[#00C2FF]" />;
    }
  };

  return (
    <section id="servicos" className="py-20 md:py-28 bg-[#080D18] text-white border-b border-white/10 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <div className="text-xs font-semibold tracking-wider uppercase text-[#00A3FF]">
            Especialidades
          </div>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white text-balance">
            Soluções completas para posicionar sua empresa com autoridade e gerar novos clientes
          </h2>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
            Seja para lançar sua primeira presença profissional ou reformular uma página que não traz resultados, temos o formato ideal para o momento do seu negócio.
          </p>
        </div>

        {/* 4 Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {SERVICES.map((service) => (
            <div
              key={service.id}
              className="bg-[#0C111E] rounded-2xl border border-white/10 p-8 shadow-xl hover:border-blue-500/50 hover:shadow-[0_0_30px_rgba(0,163,255,0.2)] transition-all duration-300 flex flex-col justify-between group"
            >
              <div className="space-y-5">
                {/* Header row with Icon and Label */}
                <div className="flex items-start justify-between gap-4">
                  <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center group-hover:scale-105 transition-transform">
                    {getServiceIcon(service.id)}
                  </div>
                  {service.badge && (
                    <span className="text-xs font-semibold text-blue-300 bg-blue-950/80 px-3 py-1 rounded-md border border-blue-500/30 shadow-[0_0_10px_rgba(0,163,255,0.15)]">
                      {service.badge}
                    </span>
                  )}
                </div>

                <div>
                  <h3 className="text-2xl font-bold text-white group-hover:text-[#00C2FF] transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-sm font-medium text-[#00A3FF] mt-1">
                    {service.tagline}
                  </p>
                </div>

                <p className="text-sm text-slate-300 leading-relaxed">
                  {service.description}
                </p>

                {/* Scope & Deliverables */}
                <div className="space-y-2.5 pt-2 border-t border-white/10">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    O que está incluso:
                  </div>
                  <ul className="space-y-2 text-sm text-slate-300">
                    {service.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-2.5">
                        <Check className="w-4 h-4 text-[#00C2FF] shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Practical Details */}
                <div className="p-4 bg-[#080D18] rounded-xl text-xs text-slate-300 border border-white/5">
                  <div>
                    <span className="font-semibold text-white">Ideal para:</span> {service.idealFor}
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-6 mt-6 border-t border-white/10">
                <a
                  href={BRAND.getWhatsAppUrl(service.whatsAppMessage)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full inline-flex items-center justify-center gap-2 bg-[#121A2D] hover:bg-gradient-to-r hover:from-[#0066FF] hover:to-[#00A3FF] text-white font-medium text-sm py-3 px-4 rounded-xl border border-white/10 hover:border-blue-400/50 hover:shadow-[0_0_20px_rgba(0,163,255,0.4)] transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
                >
                  <MessageCircle className="w-4 h-4 text-[#00C2FF] group-hover:text-white" />
                  <span>Solicitar Orçamento para {service.title}</span>
                  <ArrowRight className="w-4 h-4 ml-1 opacity-70 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Custom Project Callout */}
        <div className="mt-14 p-8 rounded-2xl bg-[#0C111E] border border-blue-500/30 shadow-[0_0_30px_rgba(0,163,255,0.15)] flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <h4 className="text-xl font-bold text-white">
              Precisa de uma estrutura personalizada ou tem dúvidas sobre qual escolher?
            </h4>
            <p className="text-sm text-slate-300 max-w-xl">
              Fale diretamente com Bruno Ribeiro. Analisamos seu segmento gratuitamente e sugerimos o melhor formato para gerar clientes para o seu negócio.
            </p>
          </div>
          <a
            href={BRAND.getWhatsAppUrl('Olá Bruno! Não tenho certeza de qual tipo de site é o ideal para o meu negócio. Podemos conversar para você me orientar?')}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-gradient-to-r from-[#0066FF] to-[#00A3FF] hover:from-[#0055DD] hover:to-[#0090EE] text-white font-semibold text-sm px-6 py-3.5 rounded-xl shrink-0 transition-all shadow-[0_0_20px_rgba(0,163,255,0.35)] whitespace-nowrap"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Falar com Bruno Agora</span>
          </a>
        </div>
      </div>
    </section>
  );
};
