import React, { useState, useEffect } from 'react';
import { BRAND } from '../data/content';
import { MessageCircle, Menu, X, Instagram } from 'lucide-react';

export const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Sobre', href: '#sobre' },
    { label: 'Serviços', href: '#servicos' },
    { label: 'Projetos', href: '#portfolio' },
    { label: 'Depoimentos', href: '#depoimentos' },
    { label: 'Contato', href: '#contato' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#05070E]/95 backdrop-blur-md shadow-2xl py-3 border-b border-blue-500/20'
          : 'bg-[#05070E]/80 backdrop-blur-sm py-4 border-b border-white/5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8">
          {/* Zone 1: Brand Wordmark with Official Logo */}
          <a
            href="#"
            className="flex items-center gap-3 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 rounded-lg shrink-0"
          >
            <div className="relative w-10 h-10 rounded-full overflow-hidden shadow-[0_0_15px_rgba(0,163,255,0.5)] border border-blue-400/60 group-hover:scale-105 transition-transform duration-200">
              <img
                src={BRAND.logo}
                alt="BRV Digital - Sites que geram resultados"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex flex-col">
              <div className="text-base font-black tracking-tight text-white flex items-center leading-tight">
                BR<span className="text-[#00A3FF]">V</span>
                <span className="ml-1.5 font-bold tracking-widest text-[11px] text-slate-300 uppercase">
                  Digital
                </span>
              </div>
              <span className="text-[9px] tracking-wider text-slate-400 font-medium">
                SITES QUE GERAM RESULTADOS
              </span>
            </div>
          </a>

          {/* Zone 2: Navigation Links (Desktop) */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-300">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="hover:text-white transition-colors relative py-1 hover:underline underline-offset-8 decoration-[#00A3FF] whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 rounded-sm"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Zone 3: Primary Action & Social Link */}
          <div className="hidden sm:flex items-center gap-4 shrink-0">
            <a
              href={BRAND.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram da BRV Digital"
              className="text-slate-300 hover:text-[#00A3FF] transition-colors p-2 rounded-lg hover:bg-white/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
              title="Instagram @brv_digital"
            >
              <Instagram className="w-5 h-5" />
            </a>
            <a
              href={BRAND.getWhatsAppUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-gradient-to-r from-[#0066FF] to-[#00A3FF] hover:from-[#0055DD] hover:to-[#0090EE] text-white font-semibold text-sm px-4 py-2.5 rounded-xl shadow-[0_0_20px_rgba(0,163,255,0.35)] hover:shadow-[0_0_25px_rgba(0,163,255,0.5)] transition-all whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
            >
              <MessageCircle className="w-4 h-4 text-white" />
              <span>Solicitar Orçamento</span>
            </a>
          </div>

          {/* Mobile hamburger button */}
          <div className="flex md:hidden items-center gap-2">
            <a
              href={BRAND.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram BRV Digital"
              className="p-2 text-slate-200 hover:text-white"
            >
              <Instagram className="w-5 h-5" />
            </a>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              type="button"
              className="p-2 text-slate-200 hover:text-white rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
              aria-label="Menu principal"
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Dropdown */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 pt-4 border-t border-white/10 pb-4 space-y-3">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="block px-3 py-2 text-base font-medium text-slate-200 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
              >
                {link.label}
              </a>
            ))}
            <div className="pt-2">
              <a
                href={BRAND.getWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white font-medium px-4 py-3 rounded-lg text-sm shadow-sm"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Solicitar Orçamento no WhatsApp</span>
              </a>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
