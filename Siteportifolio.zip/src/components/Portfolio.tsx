import React, { useState } from 'react';
import { PROJECTS, BRAND } from '../data/content';
import { Project, ProjectCategory } from '../types';
import { ProjectModal } from './ProjectModal';
import { ArrowUpRight, TrendingUp, MessageCircle, Eye } from 'lucide-react';

export const Portfolio: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<ProjectCategory>('all');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const categories: { key: ProjectCategory; label: string }[] = [
    { key: 'all', label: 'Todos os Projetos' },
    { key: 'landing-page', label: 'Landing Pages' },
    { key: 'institucional', label: 'Sites Institucionais' },
    { key: 'vendas', label: 'Páginas de Venda' },
  ];

  const filteredProjects = activeCategory === 'all'
    ? PROJECTS
    : PROJECTS.filter((p) => p.category === activeCategory);

  return (
    <section id="portfolio" className="py-20 md:py-28 bg-[#05070E] text-white border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-12">
          <div className="text-xs font-semibold tracking-wider uppercase text-[#00A3FF]">
            Portfólio Selecionado
          </div>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white text-balance">
            Projetos reais pensados para gerar autoridade e atrair clientes
          </h2>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
            Veja exemplos de páginas desenvolvidas com foco em elegância visual, velocidade extrema e máxima taxa de conversão para o WhatsApp.
          </p>
        </div>

        {/* Interactive Segmented Filter Controls */}
        <div className="flex items-center justify-center mb-12">
          <div className="inline-flex p-1 bg-[#0C111E] rounded-xl border border-white/10 overflow-x-auto max-w-full">
            {categories.map((cat) => {
              const isActive = activeCategory === cat.key;
              return (
                <button
                  key={cat.key}
                  onClick={() => setActiveCategory(cat.key)}
                  type="button"
                  className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all duration-200 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 ${
                    isActive
                      ? 'bg-gradient-to-r from-[#0066FF] to-[#00A3FF] text-white shadow-[0_0_15px_rgba(0,163,255,0.4)]'
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="group bg-[#0C111E] rounded-2xl border border-white/10 overflow-hidden hover:border-blue-500/50 hover:shadow-[0_0_30px_rgba(0,163,255,0.2)] transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Visual Image Showcase with Hover Zoom */}
                <div
                  onClick={() => setSelectedProject(project)}
                  className="relative aspect-[4/3] bg-black overflow-hidden cursor-pointer"
                >
                  <img
                    src={project.image}
                    alt={project.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                  {/* Subtle overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0C111E] via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-white bg-[#0066FF]/90 backdrop-blur-sm px-3 py-1.5 rounded-lg shadow-[0_0_15px_rgba(0,163,255,0.5)]">
                      <Eye className="w-3.5 h-3.5" />
                      <span>Ver detalhes do projeto</span>
                    </span>
                  </div>
                </div>

                {/* Card Content Area */}
                <div className="p-6 space-y-3">
                  {/* Unboxed Metadata */}
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <span className="font-semibold text-[#00A3FF]">{project.categoryLabel}</span>
                    <span aria-hidden="true">·</span>
                    <span className="truncate">{project.niche}</span>
                  </div>

                  <h3
                    onClick={() => setSelectedProject(project)}
                    className="text-xl font-bold text-white group-hover:text-[#00C2FF] transition-colors cursor-pointer leading-snug"
                  >
                    {project.title}
                  </h3>

                  <p className="text-sm text-slate-300 line-clamp-2 leading-relaxed">
                    {project.description}
                  </p>

                  {/* Impact Metric Strip */}
                  <div className="pt-3 border-t border-white/10 flex items-center justify-between">
                    <div>
                      <div className="text-xs text-slate-400">Impacto Comercial</div>
                      <div className="text-base font-bold font-mono text-[#00C2FF] tabular-nums">
                        {project.highlightMetric}
                      </div>
                    </div>
                    <div className="text-[11px] text-slate-400 max-w-[130px] text-right line-clamp-2">
                      {project.metricLabel}
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="px-6 pb-6 pt-2 flex items-center gap-3">
                <button
                  onClick={() => setSelectedProject(project)}
                  type="button"
                  className="flex-1 inline-flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl border border-white/10 hover:border-blue-500/40 hover:bg-white/5 text-xs font-semibold text-slate-200 transition-colors"
                >
                  <Eye className="w-3.5 h-3.5 text-[#00A3FF]" />
                  <span>Estudo de Caso</span>
                </button>
                <a
                  href={BRAND.getWhatsAppUrl(`Olá Bruno! Vi o projeto ${project.title} no portfólio da BRV Digital e quero solicitar um orçamento parecido.`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={`Solicitar orçamento parecido com ${project.title} no WhatsApp`}
                  className="p-2.5 rounded-xl bg-blue-500/10 hover:bg-gradient-to-r hover:from-[#0066FF] hover:to-[#00A3FF] text-[#00A3FF] hover:text-white border border-blue-500/30 transition-all"
                  title="Solicitar projeto similar"
                >
                  <MessageCircle className="w-4 h-4" />
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Global CTA below portfolio */}
        <div className="mt-16 text-center">
          <p className="text-sm text-slate-400 mb-4">
            Cada negócio possui um público e objetivo únicos. Vamos desenhar a melhor solução para o seu?
          </p>
          <a
            href={BRAND.getWhatsAppUrl('Olá Bruno! Olhei os projetos da BRV Digital e gostaria de falar sobre o meu site.')}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-gradient-to-r from-[#0066FF] to-[#00A3FF] hover:from-[#0055DD] hover:to-[#0090EE] text-white font-bold text-sm px-7 py-3.5 rounded-xl transition-all shadow-[0_0_20px_rgba(0,163,255,0.35)]"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Quero um Site no Padrão BRV Digital</span>
          </a>
        </div>
      </div>

      {/* Detail Modal */}
      <ProjectModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
      />
    </section>
  );
};
