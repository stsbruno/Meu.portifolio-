import React, { useState } from 'react';
import { BRAND } from '../data/content';
import { MessageCircle, Send, CheckCircle2, Phone, Mail, Instagram, MapPin, Clock, ArrowRight } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    serviceType: 'Landing Page de Alta Conversão',
    budget: 'R$ 1.500 a R$ 3.000',
    details: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const formatWhatsAppMessage = () => {
    return `Olá Bruno! Solicitei um orçamento pelo site da BRV Digital:\n\n*Nome:* ${formData.name || 'Não informado'}\n*WhatsApp:* ${formData.phone || 'Não informado'}\n*E-mail:* ${formData.email || 'Não informado'}\n*Tipo de Serviço:* ${formData.serviceType}\n*Faixa de Orçamento:* ${formData.budget}\n*Detalhes do Projeto:* ${formData.details || 'Gostaria de alinhar os detalhes'}`;
  };

  const handleSendWhatsApp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.phone.trim()) {
      setErrorMessage('Por favor, preencha ao menos seu nome e telefone/WhatsApp.');
      return;
    }
    setErrorMessage('');
    const message = formatWhatsAppMessage();
    const url = BRAND.getWhatsAppUrl(message);
    window.open(url, '_blank', 'noopener,noreferrer');
    setSubmitted(true);
  };

  const handleSendForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.phone.trim() || !formData.email.trim()) {
      setErrorMessage('Por favor, preencha seu nome, WhatsApp e e-mail para prosseguir.');
      return;
    }
    setErrorMessage('');
    setSubmitted(true);
  };

  return (
    <section id="contato" className="py-20 md:py-28 bg-[#05070E] text-white border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <div className="text-xs font-semibold tracking-wider uppercase text-[#00A3FF]">
            Orçamento Sem Compromisso
          </div>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white text-balance">
            Vamos construir a presença digital que o seu negócio merece?
          </h2>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
            Preencha o formulário abaixo ou envie uma mensagem direta no WhatsApp. Respondemos em poucos minutos com uma proposta personalizada.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left Column: Direct Contact & Trust Points (5 cols) */}
          <div className="lg:col-span-5 space-y-8 bg-[#0C111E] p-8 rounded-2xl border border-white/10">
            <div>
              <h3 className="text-xl font-bold text-white mb-2">
                Atendimento Direto com Bruno Ribeiro
              </h3>
              <p className="text-sm text-slate-300 leading-relaxed">
                Aqui você não passa por triagem demorada nem fala com robôs. Entendemos suas necessidades e estruturamos uma solução com rapidez.
              </p>
            </div>

            {/* Contact Channels */}
            <div className="space-y-4 text-sm text-slate-200">
              <a
                href={BRAND.getWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-3.5 rounded-xl bg-[#080D18] border border-white/5 hover:border-emerald-500/50 hover:shadow-[0_0_15px_rgba(37,211,102,0.2)] transition-all group"
              >
                <div className="w-10 h-10 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center shrink-0">
                  <MessageCircle className="w-5 h-5" />
                </div>
                <div className="truncate">
                  <div className="text-xs text-slate-400">WhatsApp Comercial</div>
                  <div className="text-sm font-bold text-white group-hover:text-emerald-400 transition-colors">
                    {BRAND.phoneFormatted}
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 ml-auto text-slate-500 group-hover:text-emerald-400 transition-colors" />
              </a>

              <a
                href={BRAND.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-3.5 rounded-xl bg-[#080D18] border border-white/5 hover:border-pink-500/50 hover:shadow-[0_0_15px_rgba(236,72,153,0.2)] transition-all group"
              >
                <div className="w-10 h-10 rounded-lg bg-pink-500/10 text-pink-400 border border-pink-500/20 flex items-center justify-center shrink-0">
                  <Instagram className="w-5 h-5" />
                </div>
                <div className="truncate">
                  <div className="text-xs text-slate-400">Instagram Oficial</div>
                  <div className="text-sm font-bold text-white group-hover:text-pink-400 transition-colors">
                    @{BRAND.instagram}
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 ml-auto text-slate-500 group-hover:text-pink-400 transition-colors" />
              </a>

              <div className="flex items-center gap-3 p-3.5 rounded-xl bg-[#080D18] border border-white/5 text-slate-200 font-medium">
                <div className="w-10 h-10 rounded-lg bg-blue-500/10 text-[#00A3FF] border border-blue-500/20 flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-slate-400">Região de Atuação</div>
                  <div className="text-sm font-bold text-white">{BRAND.location}</div>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3.5 rounded-xl bg-[#080D18] border border-white/5 text-slate-200 font-medium">
                <div className="w-10 h-10 rounded-lg bg-blue-500/10 text-[#00A3FF] border border-blue-500/20 flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-slate-400">Tempo Médio de Resposta</div>
                  <div className="text-sm font-bold text-white">Geralmente em menos de 30 minutos</div>
                </div>
              </div>
            </div>

            {/* Guarantee Box */}
            <div className="p-4 rounded-xl bg-[#080D18] border border-blue-500/30 text-xs text-slate-300 space-y-1">
              <div className="font-bold text-white flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#00C2FF]" />
                <span>Garantia de Satisfação e Suporte</span>
              </div>
              <p className="text-slate-400 leading-relaxed">
                Todo projeto inclui fase de revisão completa, treinamento para você atualizar seu conteúdo e suporte pós-entrega.
              </p>
            </div>
          </div>

          {/* Right Column: Interactive Form (7 cols) */}
          <div className="lg:col-span-7 bg-[#0C111E] p-8 sm:p-10 rounded-2xl border border-white/10 shadow-[0_0_30px_rgba(0,163,255,0.1)]">
            {submitted ? (
              <div className="text-center py-12 space-y-4 animate-fade-in">
                <div className="w-16 h-16 bg-blue-500/10 border border-blue-500/40 text-[#00C2FF] rounded-full flex items-center justify-center mx-auto shadow-[0_0_20px_rgba(0,163,255,0.3)]">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-bold text-white">
                  Solicitação Enviada com Sucesso!
                </h3>
                <p className="text-slate-300 max-w-md mx-auto text-sm leading-relaxed">
                  Obrigado pelo contato! Bruno Ribeiro já foi notificado e responderá o mais rápido possível.
                </p>
                <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                  <a
                    href={BRAND.getWhatsAppUrl(formatWhatsAppMessage())}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 bg-gradient-to-r from-[#0066FF] to-[#00A3FF] hover:from-[#0055DD] hover:to-[#0090EE] text-white font-semibold text-sm px-6 py-3 rounded-xl transition-all shadow-[0_0_20px_rgba(0,163,255,0.4)]"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Abrir Conversa no WhatsApp</span>
                  </a>
                  <button
                    onClick={() => {
                      setSubmitted(false);
                      setFormData({
                        name: '',
                        phone: '',
                        email: '',
                        serviceType: 'Landing Page de Alta Conversão',
                        budget: 'R$ 1.500 a R$ 3.000',
                        details: '',
                      });
                    }}
                    type="button"
                    className="text-xs font-semibold text-slate-400 hover:text-white underline py-2"
                  >
                    Enviar outra mensagem
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSendWhatsApp} className="space-y-6">
                <div>
                  <h3 className="text-xl font-bold text-white">
                    Solicite seu Orçamento Detalhado
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Preencha os dados e receba um retorno objetivo com prazos e valores.
                  </p>
                </div>

                {errorMessage && (
                  <div className="p-3 rounded-lg bg-red-950/60 border border-red-500/40 text-xs text-red-200 font-medium">
                    {errorMessage}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name field */}
                  <div className="space-y-1.5">
                    <label htmlFor="name" className="text-xs font-semibold text-slate-300">
                      Seu Nome Completo *
                    </label>
                    <input
                      id="name"
                      type="text"
                      required
                      placeholder="Ex: Dra. Mariana Silva"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-[#080D18] border border-white/10 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-sm text-white placeholder:text-slate-500"
                    />
                  </div>

                  {/* Phone / WhatsApp field */}
                  <div className="space-y-1.5">
                    <label htmlFor="phone" className="text-xs font-semibold text-slate-300">
                      WhatsApp com DDD *
                    </label>
                    <input
                      id="phone"
                      type="tel"
                      required
                      placeholder="(38) 99999-9999"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-[#080D18] border border-white/10 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-sm text-white placeholder:text-slate-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Email field */}
                  <div className="space-y-1.5">
                    <label htmlFor="email" className="text-xs font-semibold text-slate-300">
                      E-mail Profissional *
                    </label>
                    <input
                      id="email"
                      type="email"
                      required
                      placeholder="contato@suaempresa.com.br"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-[#080D18] border border-white/10 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-sm text-white placeholder:text-slate-500"
                    />
                  </div>

                  {/* Service selection */}
                  <div className="space-y-1.5">
                    <label htmlFor="service" className="text-xs font-semibold text-slate-300">
                      Tipo de Serviço
                    </label>
                    <select
                      id="service"
                      value={formData.serviceType}
                      onChange={(e) => setFormData({ ...formData, serviceType: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-[#080D18] border border-white/10 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-sm text-white"
                    >
                      <option value="Landing Page de Alta Conversão">Landing Page de Alta Conversão</option>
                      <option value="Site Institucional Completo">Criação de Site Institucional</option>
                      <option value="Otimização para Google (SEO)">Otimização para Google (SEO)</option>
                      <option value="Página de Vendas">Página de Vendas / Lançamento</option>
                      <option value="Reformulação de Site Existente">Reformulação de Site Existente</option>
                    </select>
                  </div>
                </div>

                {/* Details textarea */}
                <div className="space-y-1.5">
                  <label htmlFor="details" className="text-xs font-semibold text-slate-300">
                    Fale um pouco sobre sua empresa ou objetivo (opcional)
                  </label>
                  <textarea
                    id="details"
                    rows={3}
                    placeholder="Ex: Tenho uma clínica médica e quero uma landing page moderna para atrair pacientes particulares."
                    value={formData.details}
                    onChange={(e) => setFormData({ ...formData, details: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl bg-[#080D18] border border-white/10 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-sm text-white placeholder:text-slate-500 resize-none"
                  />
                </div>

                {/* Submit Buttons */}
                <div className="pt-2 flex flex-col sm:flex-row gap-3">
                  <button
                    type="submit"
                    className="flex-1 inline-flex items-center justify-center gap-2.5 bg-gradient-to-r from-[#0066FF] to-[#00A3FF] hover:from-[#0055DD] hover:to-[#0090EE] text-white font-bold text-sm py-3.5 px-6 rounded-xl transition-all shadow-[0_0_20px_rgba(0,163,255,0.4)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
                  >
                    <MessageCircle className="w-4 h-4 text-white" />
                    <span>Enviar e Abrir no WhatsApp</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleSendForm}
                    className="inline-flex items-center justify-center gap-2 border border-white/10 hover:border-white/20 bg-[#080D18] hover:bg-white/5 text-slate-200 font-medium text-sm py-3.5 px-5 rounded-xl transition-colors"
                  >
                    <Send className="w-4 h-4 text-slate-400" />
                    <span>Enviar por Mensagem</span>
                  </button>
                </div>

                <div className="text-[12px] text-slate-500 text-center">
                  🔒 Seus dados estão 100% seguros. Não enviamos spam nem compartilhamos suas informações.
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
