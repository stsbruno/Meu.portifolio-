import React from 'react';
import { BRAND, IMAGES, DIFFERENTIALS, WORK_PROCESS } from '../data/content';
import { MessageCircle, CheckCircle2, UserCheck, Shield, Clock, Compass } from 'lucide-react';

export const About: React.FC = () => {
  return (
    <section id="sobre" className="py-20 md:py-28 bg-[#05070E] text-white border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <div className="text-xs font-semibold tracking-wider uppercase text-[#00A3FF]">
            Sobre a BRV Digital
          </div>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white text-balance">
            Criamos sites modernos focados em transformar visitantes em clientes reais.
          </h2>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
            Fundada por Bruno Ribeiro, a BRV Digital nasceu para oferecer a pequenas empresas e profissionais autônomos o mesmo padrão de excelência visual e estratégia comercial antes acessível apenas a grandes marcas.
          </p>
        </div>

        {/* Profile & Story Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-20">
          {/* Profile Photo Column */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-sm lg:max-w-none">
              <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-blue-500/40 shadow-[0_0_35px_rgba(0,163,255,0.25)] bg-[#0C111E]">
                <img
                  src={IMAGES.profile}
                  alt="Bruno Ribeiro - Fundador e Desenvolvedor da BRV Digital"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center"
                  loading="lazy"
                />
              </div>

              {/* Verified Trust Card with Neon border */}
              <div className="absolute -bottom-6 -right-4 sm:right-6 bg-[#0C111E]/95 backdrop-blur-md p-4 rounded-xl border border-blue-500/40 shadow-[0_0_20px_rgba(0,163,255,0.25)] max-w-[240px]">
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-2.5 h-2.5 rounded-full bg-[#00C2FF] shadow-[0_0_8px_#00C2FF]" />
                  <span className="text-xs font-bold text-white">Bruno Ribeiro</span>
                </div>
                <p className="text-[12px] text-slate-300 leading-snug">
                  Desenvolvedor e especialista em conversão digital à frente de cada etapa do seu projeto.
                </p>
              </div>
            </div>
          </div>

          {/* Description & Mission Column */}
          <div className="lg:col-span-7 space-y-6 text-slate-300">
            <h3 className="text-2xl font-bold text-white tracking-tight">
              Seu negócio não precisa de um site genérico. Precisa de uma ferramenta ativa de vendas.
            </h3>
            
            <p className="text-base leading-relaxed text-slate-300">
              Muitos empresários investem em anúncios ou tentam atrair clientes pelas redes sociais, mas perdem vendas diariamente porque o link do perfil leva para um site lento, confuso ou amador no celular.
            </p>

            <p className="text-base leading-relaxed text-slate-300">
              Na <strong className="text-white">BRV Digital</strong>, eliminamos essa barreira. Cada linha de código e escolha visual é pensada para transmitir autoridade instantânea, tirar as principais dúvidas do seu público e facilitar ao máximo o contato direto com você no WhatsApp.
            </p>

            {/* Quick check bullets */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="flex items-start gap-2.5 text-sm text-slate-200">
                <CheckCircle2 className="w-5 h-5 text-[#00A3FF] shrink-0 mt-0.5" />
                <span>Zero templates genéricos ou ultrapassados</span>
              </div>
              <div className="flex items-start gap-2.5 text-sm text-slate-200">
                <CheckCircle2 className="w-5 h-5 text-[#00A3FF] shrink-0 mt-0.5" />
                <span>Velocidade extrema otimizada para celular</span>
              </div>
              <div className="flex items-start gap-2.5 text-sm text-slate-200">
                <CheckCircle2 className="w-5 h-5 text-[#00A3FF] shrink-0 mt-0.5" />
                <span>Textos estratégicos com técnicas de copywriting</span>
              </div>
              <div className="flex items-start gap-2.5 text-sm text-slate-200">
                <CheckCircle2 className="w-5 h-5 text-[#00A3FF] shrink-0 mt-0.5" />
                <span>Suporte humanizado e acompanhamento contínuo</span>
              </div>
            </div>

            <div className="pt-4">
              <a
                href={BRAND.getWhatsAppUrl('Olá Bruno! Gostaria de conversar com você sobre como melhorar o site do meu negócio.')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-gradient-to-r from-[#0066FF] to-[#00A3FF] hover:from-[#0055DD] hover:to-[#0090EE] text-white font-semibold text-sm px-6 py-3.5 rounded-xl transition-all shadow-[0_0_20px_rgba(0,163,255,0.35)] hover:shadow-[0_0_30px_rgba(0,163,255,0.5)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
              >
                <MessageCircle className="w-4 h-4 text-white" />
                <span>Conversar com Bruno Ribeiro no WhatsApp</span>
              </a>
            </div>
          </div>
        </div>

        {/* 4 Competitive Differentials */}
        <div className="pt-12 border-t border-white/10">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <h3 className="text-2xl font-bold text-white tracking-tight">
              Por que escolher a BRV Digital?
            </h3>
            <p className="text-sm text-slate-400 mt-2">
              Diferenciais pensados para oferecer tranquilidade, transparência e retorno tangível.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {DIFFERENTIALS.map((diff, index) => {
              const icons = [UserCheck, Clock, Shield, Compass];
              const IconComponent = icons[index % icons.length];
              return (
                <div
                  key={diff.title}
                  className="p-6 rounded-2xl bg-[#0C111E] border border-white/10 hover:border-blue-500/50 hover:shadow-[0_0_25px_rgba(0,163,255,0.2)] transition-all duration-300 flex flex-col justify-between group"
                >
                  <div className="space-y-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-[#00A3FF] group-hover:scale-110 transition-transform">
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <h4 className="text-lg font-bold text-white">
                      {diff.title}
                    </h4>
                    <p className="text-sm text-slate-400 leading-relaxed">
                      {diff.description}
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-white/10 text-xs font-semibold text-[#00A3FF]">
                    {diff.benefit}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Process Steps */}
        <div className="mt-20 pt-16 border-t border-white/10">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <div className="text-xs font-semibold tracking-wider uppercase text-[#00A3FF]">
              Etapas Claras e Transparentes
            </div>
            <h3 className="text-2xl sm:text-3xl font-bold text-white tracking-tight mt-1">
              Como funciona o desenvolvimento do seu site
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {WORK_PROCESS.map((item) => (
              <div
                key={item.step}
                className="relative space-y-3 p-5 rounded-2xl bg-[#080D18] border border-white/5 hover:border-blue-500/30 transition-colors"
              >
                <div className="text-3xl font-mono font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#00C2FF] to-[#0066FF] tabular-nums">
                  {item.step}
                </div>
                <h4 className="text-base font-bold text-white">
                  {item.title}
                </h4>
                <p className="text-sm text-slate-400 leading-relaxed">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
