import React from 'react';
import { BRAND } from '../data/content';
import { MessageCircle, Instagram, ArrowUp, Download } from 'lucide-react';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#05070E] text-slate-400 border-t border-white/10 pt-16 pb-12 relative overflow-hidden">
      {/* Subtle bottom halo glow */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-96 h-32 bg-[#00A3FF]/10 blur-[80px] pointer-events-none rounded-full" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-white/10">
          {/* Brand Col with Official Logo (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3.5">
              <div className="relative w-12 h-12 rounded-full overflow-hidden shadow-[0_0_20px_rgba(0,163,255,0.5)] border border-blue-400/60 shrink-0">
                <img
                  src={BRAND.logo}
                  alt="BRV Digital - Sites que geram resultados"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex flex-col">
                <div className="text-lg font-black tracking-tight text-white flex items-center leading-tight">
                  BR<span className="text-[#00A3FF]">V</span>
                  <span className="ml-1.5 font-bold tracking-widest text-xs text-slate-300 uppercase">
                    Digital
                  </span>
                </div>
                <span className="text-[10px] tracking-wider text-slate-400 font-medium">
                  SITES QUE GERAM RESULTADOS
                </span>
              </div>
            </div>

            <p className="text-sm text-slate-300 font-medium italic">
              "{BRAND.tagline}"
            </p>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Desenvolvimento de sites profissionais, landing pages de alta conversão e otimização para o Google para pequenas empresas e profissionais liberais em todo o Brasil.
            </p>

            {/* Social links */}
            <div className="flex items-center gap-3 pt-2">
              <a
                href={BRAND.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram da BRV Digital"
                className="w-9 h-9 rounded-lg bg-[#0C111E] hover:bg-[#0066FF] text-slate-300 hover:text-white flex items-center justify-center transition-all border border-white/10 hover:shadow-[0_0_15px_rgba(0,163,255,0.4)]"
                title="Instagram @brv_digital"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={BRAND.getWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="WhatsApp da BRV Digital"
                className="w-9 h-9 rounded-lg bg-[#0C111E] hover:bg-[#25D366] text-slate-300 hover:text-white flex items-center justify-center transition-all border border-white/10 hover:shadow-[0_0_15px_rgba(37,211,102,0.4)]"
                title="WhatsApp (38) 99989-0602"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Navigation Links Col (3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-white">
              Navegação
            </div>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#sobre" className="hover:text-[#00A3FF] transition-colors">
                  Sobre / Quem Sou
                </a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-[#00A3FF] transition-colors">
                  Serviços Oferecidos
                </a>
              </li>
              <li>
                <a href="#portfolio" className="hover:text-[#00A3FF] transition-colors">
                  Portfólio de Projetos
                </a>
              </li>
              <li>
                <a href="#depoimentos" className="hover:text-[#00A3FF] transition-colors">
                  Depoimentos de Clientes
                </a>
              </li>
              <li>
                <a href="#contato" className="hover:text-[#00A3FF] transition-colors">
                  Solicitar Orçamento
                </a>
              </li>
            </ul>
          </div>

          {/* Services Col (4 cols) */}
          <div className="lg:col-span-4 space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-white">
              Serviços Especializados
            </div>
            <ul className="space-y-2 text-sm">
              <li>
                <a
                  href={BRAND.getWhatsAppUrl('Olá Bruno! Gostaria de um orçamento para Criação de Sites.')}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors flex items-center justify-between group"
                >
                  <span className="group-hover:text-[#00A3FF] transition-colors">Criação de Sites Institucionais</span>
                </a>
              </li>
              <li>
                <a
                  href={BRAND.getWhatsAppUrl('Olá Bruno! Gostaria de um orçamento para Landing Page.')}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors flex items-center justify-between group"
                >
                  <span className="group-hover:text-[#00A3FF] transition-colors">Landing Pages de Alta Conversão</span>
                </a>
              </li>
              <li>
                <a
                  href={BRAND.getWhatsAppUrl('Olá Bruno! Gostaria de um orçamento para Otimização Google (SEO).')}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors flex items-center justify-between group"
                >
                  <span className="group-hover:text-[#00A3FF] transition-colors">Otimização para Google (SEO)</span>
                </a>
              </li>
              <li>
                <a
                  href={BRAND.getWhatsAppUrl('Olá Bruno! Gostaria de um orçamento para Páginas de Venda.')}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors flex items-center justify-between group"
                >
                  <span className="group-hover:text-[#00A3FF] transition-colors">Páginas de Vendas & Lançamento</span>
                </a>
              </li>
            </ul>

            <div className="pt-2">
              <div className="text-xs text-slate-500">Contato direto com Bruno:</div>
              <div className="text-sm font-semibold text-white">{BRAND.phoneFormatted}</div>
              <div className="text-xs text-slate-400">Instagram: @{BRAND.instagram}</div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            © {new Date().getFullYear()} BRV Digital · Bruno Ribeiro. Todos os direitos reservados.
          </div>
          <div className="flex items-center gap-6">
            <span>Brasil · Atendimento Remoto de Alto Padrão</span>
            <a
              href="/brv-digital-projeto.zip"
              download="brv-digital-projeto.zip"
              className="inline-flex items-center gap-1.5 text-slate-400 hover:text-[#00A3FF] transition-colors p-1"
              title="Baixar arquivos do projeto (.ZIP)"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Baixar ZIP do Projeto</span>
            </a>
            <button
              onClick={scrollToTop}
              type="button"
              className="inline-flex items-center gap-1.5 text-slate-400 hover:text-[#00A3FF] transition-colors p-1"
              aria-label="Voltar ao topo da página"
            >
              <span>Topo</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
