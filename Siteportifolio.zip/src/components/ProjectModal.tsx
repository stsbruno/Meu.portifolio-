import React, { useEffect } from 'react';
import { Project } from '../types';
import { BRAND } from '../data/content';
import { X, Check, MessageCircle, TrendingUp } from 'lucide-react';

interface ProjectModalProps {
  project: Project | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (project) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [project, onClose]);

  if (!project) return null;

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const whatsappMessage = `Olá Bruno! Vi o projeto "${project.title}" no seu portfólio da BRV Digital e gostaria de fazer algo parecido para o meu negócio.`;

  return (
    <div
      onClick={handleBackdropClick}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-fade-in"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div className="relative w-full max-w-3xl max-h-[90vh] bg-[#0C111E] text-white rounded-2xl shadow-[0_0_50px_rgba(0,163,255,0.25)] border border-blue-500/30 overflow-hidden flex flex-col my-auto">
        {/* Top Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-[#080D18]">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="font-semibold text-[#00A3FF]">{project.categoryLabel}</span>
            <span aria-hidden="true">·</span>
            <span>{project.niche}</span>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
            aria-label="Fechar detalhes do projeto"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto p-6 sm:p-8 space-y-6">
          {/* Main Visual Preview */}
          <div className="relative rounded-xl overflow-hidden border border-white/10 bg-black aspect-[16/9] shadow-sm">
            <img
              src={project.image}
              alt={`Apresentação do projeto ${project.title}`}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>

          {/* Title and Highlight Metric */}
          <div className="space-y-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <h3 id="modal-title" className="text-2xl sm:text-3xl font-bold text-white">
                {project.title}
              </h3>
              <div className="inline-flex items-center gap-2 bg-blue-950/60 border border-blue-500/40 px-3.5 py-1.5 rounded-lg text-blue-200 shrink-0 shadow-[0_0_15px_rgba(0,163,255,0.2)]">
                <TrendingUp className="w-4 h-4 text-[#00C2FF] shrink-0" />
                <span className="text-sm font-bold font-mono tabular-nums text-white">{project.highlightMetric}</span>
                <span className="text-xs text-[#00A3FF]">Resultado</span>
              </div>
            </div>
            <p className="text-sm text-slate-400">{project.metricLabel}</p>
          </div>

          <p className="text-base text-slate-300 leading-relaxed border-t border-white/10 pt-4">
            {project.description}
          </p>

          {/* Challenge & Solution Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-[#080D18] border border-white/10 space-y-1.5">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                O Desafio Comercial
              </div>
              <p className="text-sm text-slate-300 leading-relaxed">
                {project.challenge}
              </p>
            </div>
            <div className="p-4 rounded-xl bg-[#0E1729] border border-blue-500/30 space-y-1.5">
              <div className="text-xs font-bold uppercase tracking-wider text-[#00A3FF]">
                A Solução da BRV Digital
              </div>
              <p className="text-sm text-slate-300 leading-relaxed">
                {project.solution}
              </p>
            </div>
          </div>

          {/* Deliverables */}
          <div className="space-y-2">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
              O que entregamos neste projeto:
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {project.deliverables.map((item) => (
                <div key={item} className="flex items-center gap-2 text-sm text-slate-300">
                  <Check className="w-4 h-4 text-[#00C2FF] shrink-0" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Tech Stack */}
          <div className="flex items-center gap-2 flex-wrap pt-2 border-t border-white/10 text-xs text-slate-400">
            <span className="font-semibold text-white">Tecnologias:</span>
            {project.techStack.map((tech) => (
              <span key={tech} className="bg-[#080D18] text-slate-300 px-2.5 py-1 rounded-md border border-white/10">
                {tech}
              </span>
            ))}
          </div>
        </div>

        {/* Modal Bottom CTA */}
        <div className="p-4 sm:p-6 bg-[#080D18] border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-slate-400 text-center sm:text-left">
            Deseja uma solução personalizada para o seu nicho?
          </div>
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={onClose}
              type="button"
              className="w-1/2 sm:w-auto px-4 py-2.5 border border-white/10 text-slate-300 hover:text-white hover:bg-white/5 rounded-xl text-sm font-medium transition-colors"
            >
              Fechar
            </button>
            <a
              href={BRAND.getWhatsAppUrl(whatsappMessage)}
              target="_blank"
              rel="noopener noreferrer"
              className="w-1/2 sm:w-auto inline-flex items-center justify-center gap-2 bg-gradient-to-r from-[#0066FF] to-[#00A3FF] hover:from-[#0055DD] hover:to-[#0090EE] text-white font-bold text-sm px-5 py-2.5 rounded-xl transition-all shadow-[0_0_15px_rgba(0,163,255,0.4)] whitespace-nowrap"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Quero um Projeto Assim</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
