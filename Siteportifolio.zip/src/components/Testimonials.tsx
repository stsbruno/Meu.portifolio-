import React from 'react';
import { TESTIMONIALS, BRAND } from '../data/content';
import { Star, MessageCircle, Quote } from 'lucide-react';

export const Testimonials: React.FC = () => {
  return (
    <section id="depoimentos" className="py-20 md:py-28 bg-[#080D18] text-white border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <div className="text-xs font-semibold tracking-wider uppercase text-[#00A3FF]">
            Prova Social & Resultados Reais
          </div>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white text-balance">
            O que dizem os empresários e profissionais que confiam no nosso trabalho
          </h2>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
            Mais do que páginas publicadas, nosso compromisso é gerar impacto positivo no faturamento e na reputação dos nossos clientes.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {TESTIMONIALS.map((item) => (
            <div
              key={item.id}
              className="bg-[#0C111E] rounded-2xl border border-white/10 p-8 shadow-xl hover:border-blue-500/40 hover:shadow-[0_0_25px_rgba(0,163,255,0.15)] transition-all duration-300 flex flex-col justify-between"
            >
              <div className="space-y-4">
                {/* Top Row: Stars and Quote icon */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-amber-400">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <Quote className="w-6 h-6 text-slate-600" />
                </div>

                {/* Quote Text */}
                <p className="text-base text-slate-300 leading-relaxed italic">
                  "{item.quote}"
                </p>

                {/* Concrete Achieved Metric */}
                <div className="p-3 bg-blue-950/50 border border-blue-500/30 rounded-xl text-xs text-blue-200 font-medium">
                  <span className="font-bold text-[#00C2FF]">Resultado comprovado:</span> {item.metricAchieved}
                </div>
              </div>

              {/* Author Info */}
              <div className="pt-6 mt-6 border-t border-white/10 flex items-center gap-4">
                <div className="w-11 h-11 rounded-full bg-[#080D18] border border-blue-400/50 text-[#00C2FF] flex items-center justify-center font-bold text-sm tracking-wider shrink-0 shadow-[0_0_12px_rgba(0,163,255,0.3)]">
                  {item.avatarText}
                </div>
                <div>
                  <div className="text-sm font-bold text-white">
                    {item.name}
                  </div>
                  <div className="text-xs text-slate-400">
                    {item.role} · <span className="text-slate-300 font-medium">{item.company}</span>
                  </div>
                  <div className="text-[11px] text-[#00A3FF] font-medium mt-0.5">
                    {item.niche}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Adjacency Trust Strip */}
        <div className="mt-16 bg-[#0C111E] rounded-2xl border border-blue-500/30 p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-[0_0_30px_rgba(0,163,255,0.15)]">
          <div className="space-y-1 text-center sm:text-left">
            <h4 className="text-lg font-bold text-white">
              Quer ser o próximo caso de sucesso da BRV Digital?
            </h4>
            <p className="text-sm text-slate-300">
              Solicite uma análise do seu site atual ou receba uma proposta para um projeto novo.
            </p>
          </div>
          <a
            href={BRAND.getWhatsAppUrl('Olá Bruno! Vi os depoimentos no site da BRV Digital e quero agendar uma conversa sobre o meu projeto.')}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-gradient-to-r from-[#0066FF] to-[#00A3FF] hover:from-[#0055DD] hover:to-[#0090EE] text-white font-bold text-sm px-6 py-3 rounded-xl transition-all shrink-0 shadow-[0_0_20px_rgba(0,163,255,0.35)] whitespace-nowrap"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Falar com Bruno no WhatsApp</span>
          </a>
        </div>
      </div>
    </section>
  );
};
