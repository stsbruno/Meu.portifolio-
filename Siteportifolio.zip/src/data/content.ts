import { Project, ServiceItem, Testimonial, Differential } from '../types';

export const BRAND = {
  name: 'BRV Digital',
  founder: 'Bruno Ribeiro',
  role: 'Criação de Sites e Especialista em Conversão Web',
  tagline: 'Transformamos a sua presença digital em oportunidades',
  subTagline: 'Sites que geram resultados',
  logo: '/assets/aistudio/5BB8E696-6D41-47D7-B06F-0B7B129FE8A0_36871989.png',
  location: 'Atendimento em todo o Brasil',
  phone: '5538999890602',
  phoneFormatted: '(38) 99989-0602',
  instagram: 'brv_digital',
  instagramUrl: 'https://www.instagram.com/brv_digital',
  email: 'contato@brvdigital.com.br',
  defaultWhatsAppMessage: 'Olá Bruno! Vim pelo site da BRV Digital e gostaria de solicitar um orçamento para o meu projeto de site.',
  getWhatsAppUrl: (customMessage?: string) => {
    const text = encodeURIComponent(customMessage || BRAND.defaultWhatsAppMessage);
    return `https://wa.me/${BRAND.phone}?text=${text}`;
  },
};

export const IMAGES = {
  hero: '/assets/images/hero_site_br_pt_1792776318026.jpg',
  profile: '/assets/aistudio/IMG_0378_ef075ecf.jpeg',
  projects: {
    lawFirm: '/assets/images/projeto_advocacia_pt_1792776320164.jpg',
    medicalClinic: '/assets/images/projeto_clinica_pt_1792776320857.jpg',
    solarEnergy: '/assets/images/projeto_energia_solar_pt_1792776322200.jpg',
  },
};

export const DIFFERENTIALS: Differential[] = [
  {
    title: 'Atendimento Humanizado',
    description: 'Você lida diretamente com Bruno Ribeiro, sem intermediários ou atendentes terceirizados. Conversas ágeis e alinhamento total de expectativas.',
    benefit: 'Comunicação direta e sem ruídos',
  },
  {
    title: 'Prazos Rápidos',
    description: 'Processo ágil e metodologia estruturada para colocar seu site no ar com rapidez, sem semanas de espera ou burocracia desnecessária.',
    benefit: 'Seu projeto no ar com agilidade',
  },
  {
    title: 'Foco em Conversão',
    description: 'Não fazemos apenas sites bonitos. Cada chamada para ação, disposição visual e velocidade é pensada para transformar visitantes em contatos no WhatsApp.',
    benefit: 'Retorno real sobre o investimento',
  },
  {
    title: 'Design Exclusivo',
    description: 'Projetos desenvolvidos sob medida para a sua marca e segmento. Nada de modelos genéricos ou sites que parecem cópias dos concorrentes.',
    benefit: 'Autoridade e credibilidade imediata',
  },
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'criacao-sites',
    title: 'Criação de Sites',
    tagline: 'Sites institucionais modernos que transmitem autoridade imediata',
    description: 'Desenvolvimento completo de sites corporativos para empresas e profissionais liberais. Estrutura multi-páginas, integração com WhatsApp, blog opcional e painel intuitivo.',
    idealFor: 'Empresas, escritórios de advocacia, clínicas e consultores consolidados.',
    estimatedDelivery: '',
    features: [
      'Design responsivo para celular, tablet e computador',
      'Estrutura multi-páginas (Início, Sobre, Serviços, Contato)',
      'Integração direta com WhatsApp e formulários seguros',
      'Painel para atualizações simples e autônomas',
      'Certificado de Segurança SSL e hospedagem otimizada',
    ],
    whatsAppMessage: 'Olá Bruno! Tenho interesse na Criação de um Site Institucional para a minha empresa. Podemos conversar sobre um orçamento?',
    badge: 'Mais Completo',
  },
  {
    id: 'landing-pages',
    title: 'Landing Pages',
    tagline: 'Páginas de alta conversão para transformar tráfego em clientes',
    description: 'Páginas focadas em um único objetivo comercial: atrair o visitante, quebrar objeções e levá-lo diretamente para fechar negócio com você no WhatsApp ou telefone.',
    idealFor: 'Anúncios no Google/Meta, profissionais liberais e captação de leads.',
    estimatedDelivery: '',
    features: [
      'Copywriting persuasivo e arquitetura orientada à venda',
      'Carregamento ultra-rápido (menos de 1.2 segundos)',
      'Botões de WhatsApp estratégicos e rastreáveis',
      'Gatilhos de prova social, depoimentos e garantias',
      'Pronta para receber campanhas de Google Ads e tráfego pago',
    ],
    whatsAppMessage: 'Olá Bruno! Gostaria de um orçamento para uma Landing Page de alta conversão para o meu negócio.',
    badge: 'Mais Procurado',
  },
  {
    id: 'otimizacao-google',
    title: 'Otimização para Google (SEO)',
    tagline: 'Seja encontrado por quem já está procurando pelos seus serviços',
    description: 'Adequação técnica completa do seu site para os critérios mais exigentes do Google: velocidade máxima, dados estruturados (Schema.org) e SEO local para sua região.',
    idealFor: 'Negócios locais e empresas que desejam atrair clientes sem depender só de anúncios.',
    estimatedDelivery: '',
    features: [
      'Otimização Core Web Vitals (nota verde no Google PageSpeed)',
      'Configuração de meta tags, títulos e dados estruturados Schema',
      'Estruturação de palavras-chave para seu nicho e cidade',
      'Indexação oficial no Google Search Console',
      'Otimização de rotas locais para busca no Google Meu Negócio',
    ],
    whatsAppMessage: 'Olá Bruno! Preciso otimizar meu site para o Google (SEO) para aparecer melhor nas buscas. Pode me ajudar?',
  },
  {
    id: 'paginas-venda',
    title: 'Páginas de Venda',
    tagline: 'Estruturas de alta conversão para produtos e serviços de alto valor',
    description: 'Páginas completas de apresentação de ofertas com visual imersivo, quebra minuciosa de objeções, vídeos de vendas, seções de FAQ e direcionamento para checkout ou WhatsApp comercial.',
    idealFor: 'Mentorias, infoprodutos, consultorias de alto valor e lançamentos.',
    estimatedDelivery: '',
    features: [
      'Seções de oferta irresistível e ancoragem de valor',
      'Tabelas comparativas e demonstração clara de benefícios',
      'Integração com gateways de pagamento ou WhatsApp',
      'Módulo de perguntas frequentes interativo (FAQ)',
      'Design refinado com microinterações e alta retenção',
    ],
    whatsAppMessage: 'Olá Bruno! Gostaria de desenvolver uma Página de Vendas com foco em alta conversão. Gostaria de um orçamento.',
  },
];

export const PROJECTS: Project[] = [
  {
    id: 'vasconcelos-advocacia',
    title: 'Vasconcelos Advocacia Empresarial',
    client: 'Vasconcelos & Associados',
    category: 'institucional',
    categoryLabel: 'Site Institucional',
    niche: 'Direito Empresarial & Tributário',
    description: 'Plataforma institucional corporativa para escritório de advocacia empresarial, combinando sobriedade, agilidade técnica e captação qualificada de clientes.',
    highlightMetric: '+160%',
    metricLabel: 'Aumento em consultas qualificadas nos primeiros 45 dias',
    image: IMAGES.projects.lawFirm,
    fallbackGradient: 'from-slate-900 to-[#0A2540]',
    challenge: 'O escritório possuía um site antigo, desatualizado e não responsivo, gerando baixa credibilidade perante médias e grandes empresas.',
    solution: 'Criamos uma presença digital minimalista com paleta azul marinho e dourado sóbrio, tipografia refinada e formulários segmentados por área de atuação jurídica.',
    deliverables: [
      'Arquitetura institucional com páginas de especialidades',
      'Otimização de tempo de carregamento para 0.9s',
      'Integração com WhatsApp institucional da banca',
    ],
    techStack: ['React', 'TypeScript', 'Tailwind CSS', 'SEO Técnico'],
  },
  {
    id: 'lumina-estetica',
    title: 'Clínica Lumina Estética Avançada',
    client: 'Dra. Gabriela Vasconcellos',
    category: 'landing-page',
    categoryLabel: 'Landing Page',
    niche: 'Saúde & Estética Premium',
    description: 'Landing page de alta conversão para clínica médica dermatológica, com apresentação de procedimentos estéticos e agendamento direto pelo WhatsApp.',
    highlightMetric: '2.8x mais',
    metricLabel: 'Agendamentos mensais após o lançamento da nova página',
    image: IMAGES.projects.medicalClinic,
    fallbackGradient: 'from-emerald-950 to-teal-900',
    challenge: 'A clínica investia em anúncios no Instagram, mas os visitantes abandonavam a página antiga sem clicar para agendar consulta.',
    solution: 'Reformulamos a narrativa com foco em autoridade médica, depoimentos com fotos de resultados, tabela de dúvidas frequentes e botões de agendamento em pontos estratégicos.',
    deliverables: [
      'Copywriting persuasivo e humanizado',
      'Sistema de agendamento rápido via WhatsApp',
      'Botão flutuante de WhatsApp inteligente com pré-mensagem',
    ],
    techStack: ['React', 'Mobile First', 'Microanimações', 'Google Analytics 4'],
  },
  {
    id: 'solaris-engenharia',
    title: 'Solaris Energia Solar',
    client: 'Solaris Engenharia B2B',
    category: 'vendas',
    categoryLabel: 'Página de Venda B2B',
    niche: 'Energia Solar e Projetos Comerciais',
    description: 'Página de vendas focada no público empresarial e rural, apresentando gráficos de economia financeira e captação de orçamentos de grande porte.',
    highlightMetric: 'R$ 480k+',
    metricLabel: 'Em propostas comerciais originadas pela página em 60 dias',
    image: IMAGES.projects.solarEnergy,
    fallbackGradient: 'from-blue-950 to-sky-900',
    challenge: 'Explicar a viabilidade técnica e financeira da instalação fotovoltaica de forma clara e convincente para diretores de empresas.',
    solution: 'Desenvolvemos uma página interativa com apresentação em blocos visuais, demonstrativo de retorno sobre investimento e chamada direta para os consultores.',
    deliverables: [
      'Estrutura com demonstrativo de geração e economia acumulada',
      'Apresentação de certificações e projetos entregues',
      'Formulário qualificado com direcionamento direto para WhatsApp',
    ],
    techStack: ['React', 'TypeScript', 'Tailwind', 'Schema.org'],
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'Dr. Rodrigo Vasconcelos',
    role: 'Sócio-Diretor',
    company: 'Vasconcelos Advocacia Tributária',
    niche: 'Direito Empresarial',
    avatarText: 'RV',
    rating: 5,
    quote: 'O atendimento com o Bruno foi direto e sem enrolação. Ele entendeu exatamente a sobriedade que um escritório de advocacia precisa, entregando o site completo com muita agilidade. No primeiro mês já fechamos contratos que pagaram o investimento várias vezes.',
    metricAchieved: 'Contrato corporativo fechado na primeira semana após o ar',
  },
  {
    id: '2',
    name: 'Dra. Camila Duarte',
    role: 'Médica Dermatologista',
    company: 'Clínica Duarte Dermatologia',
    niche: 'Saúde & Procedimentos',
    avatarText: 'CD',
    rating: 5,
    quote: 'Eu estava cansada de pagar agências que cobravam caro e demoravam 2 meses para entregar algo genérico. O Bruno fez uma Landing Page linda, rápida e que realmente faz as pessoas clicarem no WhatsApp para marcar consulta. Minha agenda lotou.',
    metricAchieved: '+140% no volume de pacientes particulares agendados',
  },
  {
    id: '3',
    name: 'Marcelo Faria',
    role: 'Diretor Comercial',
    company: 'Solaris Engenharia',
    niche: 'Energia Solar B2B',
    avatarText: 'MF',
    rating: 5,
    quote: 'O site que a BRV Digital construiu colocou a nossa empresa em outro patamar de autoridade no mercado regional. O design passa confiança imediata e os clientes já chegam no WhatsApp elogiando a clareza das informações.',
    metricAchieved: 'Mais de 35 solicitações de orçamento nos primeiros 30 dias',
  },
  {
    id: '4',
    name: 'Juliana Neves',
    role: 'Nutricionista & Mentora',
    company: 'Juliana Neves Saúde Integrativa',
    niche: 'Nutrição & Cursos',
    avatarText: 'JN',
    rating: 5,
    quote: 'A página de vendas feita pelo Bruno transmitiu o posicionamento de alto valor que eu precisava. Consegui aumentar o valor da minha consulta e o lançamento da minha consultoria esgotou em 4 dias. Recomendo de olhos fechados!',
    metricAchieved: 'Reajuste de 60% no valor da consulta com aprovação imediata',
  },
];

export const WORK_PROCESS = [
  {
    step: '01',
    title: 'Diagnóstico & Estratégia',
    description: 'Entendemos seu modelo de negócio, seus diferenciais e seu cliente ideal para desenhar a melhor estrutura comercial para a sua página.',
  },
  {
    step: '02',
    title: 'Design Exclusivo & Copywriting',
    description: 'Criamos o layout personalizado e textos persuasivos com foco total em prender a atenção do visitante e levá-lo à ação.',
  },
  {
    step: '03',
    title: 'Desenvolvimento & Velocidade',
    description: 'Programação limpa, código veloz, otimização completa para celular e integração com WhatsApp, métricas e Google.',
  },
  {
    step: '04',
    title: 'Revisão, Publicação & Suporte',
    description: 'Ajustes finos com você, ativação no seu domínio próprio, testes finais e suporte humanizado para sua tranquilidade.',
  },
];
