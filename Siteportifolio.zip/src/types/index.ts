export type ProjectCategory = 'all' | 'landing-page' | 'institucional' | 'vendas';

export interface Project {
  id: string;
  title: string;
  client: string;
  category: ProjectCategory;
  categoryLabel: string;
  niche: string;
  description: string;
  highlightMetric: string;
  metricLabel: string;
  image: string;
  fallbackGradient: string;
  liveUrlMock?: string;
  challenge: string;
  solution: string;
  deliverables: string[];
  techStack: string[];
}

export interface ServiceItem {
  id: string;
  title: string;
  tagline: string;
  description: string;
  idealFor: string;
  estimatedDelivery: string;
  features: string[];
  whatsAppMessage: string;
  badge?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  niche: string;
  avatarText: string;
  rating: number;
  quote: string;
  metricAchieved: string;
}

export interface Differential {
  title: string;
  description: string;
  benefit: string;
}
