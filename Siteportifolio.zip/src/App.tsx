import React from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Services } from './components/Services';
import { Portfolio } from './components/Portfolio';
import { Testimonials } from './components/Testimonials';
import { ContactSection } from './components/ContactSection';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-[#05070E] text-slate-200 font-sans selection:bg-[#0070F3] selection:text-white">
      {/* Top Bar Navigation */}
      <Header />

      {/* Main Content Sections (Strict Order as Requested) */}
      <main className="flex-1">
        {/* 1. Seção inicial impactante */}
        <Hero />

        {/* 2. Sobre / Quem sou */}
        <About />

        {/* 3. Serviços */}
        <Services />

        {/* 4. Portfólio / Projetos */}
        <Portfolio />

        {/* 5. Depoimentos */}
        <Testimonials />

        {/* 6. Formulário de contato */}
        <ContactSection />
      </main>

      {/* 7. WhatsApp Flutuante */}
      <FloatingWhatsApp />

      {/* High-end Corporate Footer */}
      <Footer />
    </div>
  );
}
